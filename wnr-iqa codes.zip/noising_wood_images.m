clear all;
close all;
clc;
%addpath ('C:\Users\acer\Desktop\Wood Images\Original Images\Ref_Im')
%% READ WOOD ORIGINAL IMAGE
z = 362;
[filename,path] = uigetfile('*.*', 'Select Image','C:\Users\acer\Desktop\Wood Images\Original Images\Ref_Im\yellowheart.bmp');
pathname = [path, filename];
Ref_im = imread(pathname);
Ref_im = rgb2gray(Ref_im);
save([num2str(z) '.mat'],'Ref_im');
imwrite(uint8(Ref_im),sprintf('%d.bmp',z))
imshow(Ref_im);
Ref_im = double(Ref_im);
Ref_im = (Ref_im/ max(Ref_im(:)))*255;
save([num2str(z) '.mat'],'Ref_im');
imwrite(uint8(Ref_im),sprintf('%d.bmp',z))
% GAUSSIAN WHITE NOISE
i = 0;
for sgb = 10:10:90;
     z = z+1;
     i = i+1;
gwn_img = Ref_im + sgb*randn(size(Ref_im)) ;
save([num2str(z) '.mat'],'gwn_img');
imwrite(uint8(gwn_img),sprintf('%d.bmp',z))

MSSIM(i,1)= msssim(Ref_im, gwn_img);
SSIM(i,1)= metrix_ssim(Ref_im, gwn_img);
FSIM(i,1)= FeatureSIM(Ref_im, gwn_img);
[iwssim(i,1) iwmse(i,1) iwpsnr(i,1)]= IW_SSIM_MSE_PSNR_FR(Ref_im, gwn_img);
IWSSIM(i,1)=iwssim(i,1);
[score_WN(i,1), quality_map] = GMSD(Ref_im, gwn_img);
GMSD_WN (i,1) = score_WN (i,1);
VIF(i,1) = vifvec(Ref_im, gwn_img);
end
% GAUSSIAN BLUR
for m = 2:2:18;
     z = z+1;
     i = i+1;
mb = fspecial('motion',m,0);
mb_I = imfilter(Ref_im, mb,'replicate');
save([num2str(z) '.mat'],'mb_I');
imwrite(uint8(mb_I),sprintf('%d.bmp',z))

MSSIM(i,1)= msssim(Ref_im, mb_I);
SSIM(i,1)= metrix_ssim(Ref_im, mb_I);
FSIM(i,1)= FeatureSIM(Ref_im, mb_I);
[iwssim(i,1) iwmse(i,1) iwpsnr(i,1)]= IW_SSIM_MSE_PSNR_FR(Ref_im, mb_I);
IWSSIM(i,1)=iwssim(i,1);
[score(i,1), quality_map] = GMSD(Ref_im, mb_I);
[score_WN(i,1), quality_map] = GMSD(Ref_im, mb_I);
GMSD_WN (i,1) = score_WN (i,1);
VIF(i,1) = vifvec(Ref_im, gwn_img);
end