clear all;close all;clc;
    
%%%% C:\Users\acer\Desktop\Wood Images\Latest Wood Dataset generated 210818\All images_bmp

[filename,path] = uigetfile('*.*', 'Select Image','C:\Users\acer\Desktop\Wood Images\Latest Wood Dataset generated 210818\All images_bmp\372.bmp');
pathname = [path, filename];
I = imread(pathname);
imshow(I);
I = double(I);
I = (I/ max(I(:)))*255;
imdist = I;
imdist = double(imdist);

% if(nargin<2)
feat_test = brisque_feature(imdist);
% disp('feat computed')
save feat_test feat_test

% Process calculated features
load MaxV
load MinV
%scaled_trial = scaleSVM_H(feat_test_mri,MaxV,MinV);

%Scale the trial data
[R C] = size(feat_test);
scaled = (feat_test-MinV)./(MaxV-MinV);
for i=1:size(feat_test,2)
    if(all(isnan(scaled(:,i))))
        scaled(:,i)=0;
    end
end
trial_data=scaled;
save trial_data trial_data

load model

[y_trial, Acc_trial, projection_trial] = svmpredict(0,trial_data,model);
Image_Quality = y_trial;
