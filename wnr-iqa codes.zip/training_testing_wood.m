clear all; close all; clc;
tic
%addpath('K:\Work for Paper 3\SVR training and testing with ref dmos\libsvm-3.20\libsvm-3.20\matlab')


%LOAD THE DATA

% load DMOS_latest_ref
% dmos = DMOS;
% clear DMOS

% load FEAT_latest_ref_norm
% feat = FEAT;
% clear FEAT

[mos] = xlsread('mos for latest wood database 250818.xlsx');

[feat] = xlsread('features only for latest wood database 250818.xlsx');

for iter = 1:10
I = randperm(380);
trn_data.X = feat(I(1:304),:);
trn_data.y = dmos(I(1:304));

tst_data.X = feat(I(305:380),:);
tst_data.y = dmos(I(305:380));

resultchoice = 1;


%PROCESS DATA
[trn_data, tst_data,MaxV,MinV] = scaleSVM_CL(trn_data,tst_data,0,1);    %scale trn and tst set 0-1

wood_data.X = [trn_data.X; tst_data.X];
wood_data.y = [trn_data.y; tst_data.y];
save trn_data trn_data
save tst_data tst_data
save MaxV MaxV
save MinV MinV
%SVM
%PERFORM MODEL SELECTION
param.s = 3;
%param.C = max(trn_data.y)-min(trn_data.y);
param.Cset = 2.^[0:15];
param.t = 2;
param.gset = 2.^[-15:15];

val_data.X = tst_data.X;
val_data.y = tst_data.y;

CC_training = zeros(length(param.Cset),length(param.gset));


for j=1:length(param.Cset)
    param.C = param.Cset(j);
    
    for k=1:length(param.gset)
        param.g = param.gset(k);
        
        param.libsvm = ['-s ', num2str(param.s), ' -t ', num2str(param.t), ...
            ' -c ', num2str(param.C), ' -g ', num2str(param.g)];
        
        %BUILD MODEL ON TRAINING DATA
        model = svmtrain(trn_data.y,trn_data.X,param.libsvm);
        
        %PREDICT ON THE VALIDATION DATA
        [y_hat, Acc, projection] = svmpredict(val_data.y,val_data.X,model);
        %         CC_temp = scatterplotnew(y_hat,val_data.y,'Gaussian Blur',0);
        
%         MSE_training(j,k) = sum((y_hat-val_data.y).^2)/size(y_hat,1);

% CORRELATION BETWEEN SVM PREDICTED SCORE (FROM VALIDATION DATA) AND VALIDATION DATA
        [TempResult(1,1) TempResult(1,2)] = scatterplotcl(y_hat,val_data.y,0);
        
        % IF RESULTCHOICE = 1 ; TAKE PLCC AS CC_TRAINING
        % IF RESULTCHOICE = 2 ; TAKE SROCC AS CC_TRAINING
        CC_training(j,k) = TempResult(1,resultchoice);    
    end
    
end


% [v1,i1] = min(MSE_training);
% [v2,i2] = min(v1);

% SELECT PARAMETERS ( WITH MAXIMUM SROCC/PLCC)
[v1,i1] = max(CC_training);
[v2,i2] = max(v1);
optparam = param;
optparam.C = param.Cset(i1(i2));
optparam.g = param.gset(i2);

%train and test on training, val and all data
optparam.libsvm = ['-s ', num2str(optparam.s), ' -t ', num2str(optparam.t), ...
    ' -c ', num2str(optparam.C), ' -g ', num2str(optparam.g)];

model = svmtrain(trn_data.y, trn_data.X, optparam.libsvm);

save model model
%y_trn  = predicted score from training data
[y_trn,Acc,projection] = svmpredict(trn_data.y,trn_data.X,model);

%calculate correlation between y_trn and training data
[CC(1),SROCC(1),MAE(1),RMS(1)] = scatterplotcl(y_trn, trn_data.y,0);

%y_tst = predicted score from testing data
[y_tst,Acc,projection] = svmpredict(tst_data.y,tst_data.X,model);

%calculate correlation between y_tst and testing data
[CC(2),SROCC(2),MAE(2),RMS(2)] = scatterplotcl(y_tst, tst_data.y,0);

%y_wood = predicted score from whole wood data
[y_wood,Acc,projection] = svmpredict(wood_data.y,wood_data.X,model);
%calculate correlation between y_wood and whole wood data
[CC(3),SROCC(3),MAE(3),RMS(3)] = scatterplotcl(y_wood, wood_data.y,0);

results_trn(iter,:) = [CC(1) SROCC(1) MAE(1) RMS(1) optparam.C optparam.g];
results_tst(iter,:) = [CC(2) SROCC(2) MAE(2) RMS(2)];
end

%rmpath('K:\Work for Paper 3\SVR training and testing with ref dmos\libsvm-3.20\libsvm-3.20\matlab')

toc